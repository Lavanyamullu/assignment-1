/*  JFM1T2_Assignment6:

    Write a program that swaps the values of 2 variables without using third variable.
    Prompt the user input from the terminal.
    
    Sample Input:
    Enter first number: 
    12
    Enter second number: 
    45
    
    Expected Output:
    Before swapping: 12 , 45
    After swapping: 45 , 12
*/

//import statements for java program to read inputs using Scanner class
import java.util.Scanner;

public class Swapping {
public static void main(String []args)
  {
    int r,s,t;
    Scanner p=new Scanner(System.in);
    System.out.println("Swapping numbers:");
      System.out.println("Enter first number");
    r=p.nextInt();
    System.out.println("Enter second number");
    s=p.nextInt();
    System.out.println("before swapping numbers: "+r +"  "+ s);  
       t = r;  
       r = s;  
       s= t; 
       System.out.println("After swapping: "+r +"   " + s);  
       System.out.println( );  
  }

}