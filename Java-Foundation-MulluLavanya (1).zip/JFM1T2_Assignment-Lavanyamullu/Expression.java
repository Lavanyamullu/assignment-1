/*  JFM1T2_Assignment7:

     Assume that the integer variable a is 20 and b is 10. Evaluate the following expressions and print the value of resultant variable:
     1. int b= a-- - --a;
     2. int c=a--;
     3. int d=a>>2;
     4. int e=a&b;
     Prompt the user input from the terminal.
     
     Sample Input:
     Enter a value: 
     20
     Enter b value: 
     10
     
     Expected Output:
     a-- - --a is: 2
     a-- is: 18
     a>>2 is: 4
     a&b is: 0
*/

//import statements for java program to read inputs using Scanner class
import java.util.Scanner;
public class Expression {
 public static void main (String[] args) {
    Scanner t=new Scanner(System.in);
    System.out.println("Enter numbers:");
    int a=t.nextInt();
    int b=t.nextInt();
    int x= a-- - --a;
    int y=a--;
    int p=a>>2;
    int q=a&b;
    System.out.println("a-- - --a:"+x);
    System.out.println("a--:"+y);
    System.out.println("a>>2:"+p);
    System.out.println("a&&b:"+q);
  }
}