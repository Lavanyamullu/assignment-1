import java.util.*;

class test {
  public static void main(String l[]) {
    String str2 = new String("WelcomE to bitlabs e");
    // search methods
    // 1. indexOf()
    System.out.println(str2.indexOf("el"));
    System.out.println(str2.indexOf("el", 5));

  }
}